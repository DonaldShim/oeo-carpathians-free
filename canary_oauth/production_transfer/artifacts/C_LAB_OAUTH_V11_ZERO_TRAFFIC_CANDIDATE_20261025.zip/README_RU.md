# C-Lab OAuth V11 — отдельная Cloud Run revision, 0% traffic

**Статус:** `BECOMING / LOCAL_32_OF_32_PASS / CLOUD_REVISION_NOT_CREATED`.

## Назначение

Изолированная проверка **альтернативного OAuth-carrier** (собственный AS + защищённый MCP) для существующей Cloud Run службы `c-lab-gcp-control`. Не заменяет Google OAuth, не отправляет scientific jobs, не использует C-Fabric, не меняет текущий production plugin.

**Критически важно:** это **синтетический test-only OAuth-прототип**, а не полноценный провайдер авторизации. `/authorize` намеренно возвращает 503 (`real_identity_provider_not_configured`); выдача code требует отдельного operator-secret через `/test/issue-code`; `client_id=C_LAB_SYNTHETIC_V11`, а не настоящий ChatGPT. Состояние хранится в памяти и **не переживает restart**. Поэтому настоящие Google login, ChatGPT OAuth linking, refresh в ChatGPT и миграция C-Lab здесь **НЕ ДОКАЗАНЫ**.

## Что реально выполнено

`python -m pytest -q test_app.py test_cloudrun_gate.py` → **32/32 PASS**.

Наблюдаемые механизмы: PKCE S256, resource binding, refresh rotation, `refresh`-replay rejection, access expiry → refresh → protected synthetic MCP read, no-science admission, isolated operator proof, fail-closed staging guard (отдельный service account, pinned image digest, отдельный secret, 0% production traffic, tagged revision readback).

Read-only health основного C-Lab после разработки: `get_control_health ok=true`, `v54-ingress` и `fabric-runtime` healthy HTTP 200. `PRODUCTION_CHANGES=0`, `SCIENCE_JOBS_CREATED=0` (со стороны этого исследования).

Локальное использование `cloudrun_gate.py` вернуло `OPEN / AUTHORIZED_GCLOUD_RUNTIME_UNAVAILABLE / deployed=false`. Никаких подмен deployment-свидетельств.

## Gate 0 — что требуется до создания revision

1. Актуальный read-only `gcloud run services describe` самого `c-lab-gcp-control` и SHA/generation текущего traffic contract. Исторический V10 показывал 100% на `c-lab-gcp-control-custody-v1-prod-20261020` — **нельзя считать это вечным инвариантом**.
2. Пинованный `@sha256` **независимо собранного** synthetic-only образа в Artifact Registry, SHA-verified исходный код.
3. Заранее созданная ограниченная service identity **НЕ production SA**. IAM audit обязан доказать, что у неё нет доступа к C-Fabric, scientific storage, Google Cloud admin, production secrets. Разрешить при необходимости лишь чтение одного отдельного test-only Secret Manager секрета.
4. Отдельный секрет `C_LAB_V11_OPERATOR_KEY` (только для синтетического тестового кода) в Secret Manager; не печатать ключ и не сохранять в ZIP/GitHub/чате.
5. Явное разрешение на Google Cloud billing за сборку/ревизию, если операции требуют оплаты.
6. Проверка, что тестовый tagged URL может быть вызван напрямую даже при 0% трафика. Инструмент не должен открывать scientific endpoints.

## Команда после Gate 0

Это пример **подготовленной операции, а не отчёт о выполненном deployment**:

```bash
python cloudrun_gate.py \
  --candidate-image 'europe-west1-docker.pkg.dev/project-4e9f56f4-a524-4759-91f/isolated/oauth-v11-test@sha256:<verified-64-hex>' \
  --candidate-service-account '<approved-isolated-sa>@project-4e9f56f4-a524-4759-91f.iam.gserviceaccount.com' \
  --test-secret-ref 'v11-test-only-operator:1' \
  --execute --acknowledge-tagged-url \
  --output 'CLOUD_RUN_DEPLOY_RECEIPT.json'
```

`cloudrun_gate.py` сначала проверяет baseline, запускает строго `gcloud run deploy ... --no-traffic --tag oauth-v11`, очищает секреты/переменные/тома/Cloud SQL/VPC connector из нового ревизионного шаблона, требует отдельную test identity и сверяет после deploy 100% traffic baseline, tagged revision, image digest, service identity и имена env vars. Скрипт не выдаёт GCP-ключи и не изменяет IAM.

**0% traffic не означает, что tagged URL закрыт от Интернета.** Это тестовый поверхностный сервис без доступа к C-Fabric; при открытом Cloud Run service-level IAM tagged URL может оказаться общедоступным. Ревизия потенциально платная даже при нулевом трафике (зависит от ресурсоёмкости и min instances); запретить выделенные minimum instances.

## Критерий следующего фрукта

Для `AFFIRMED_ZERO_TRAFFIC_REVISION`: Cloud Run `status=Ready`, digest из действительно собранного immutable image, `production_before == production_after` по точному revision-percentage, candidate=0%, candidate-only tagged URL и подтверждённые env/service-account restrictions; затем HTTP smoke к tag.

Для `AFFIRMED_REAL_OAUTH`: заменить синтетическую выдачу code на **настоящую OIDC-идентификацию** с Google или иным удостоверенным provider, безопасное долговременное хранилище tokens+refresh, клиентская PKCE/CIMD/private_key_jwt проверка, реальный вход владельца. Вывести защищённый MCP только для тестового ресурса; затем actual ChatGPT read → expiry → refresh → read без reconnect.

Для `TRANSFER_FRUIT`: отдельный review полноценного production contract, proof of backward compatibility, scoped IAM, rollback, no-science regression, и только затем обсуждать cutover. Настоящий Google OAuth production при этом сохраняется.

## Результат

- **Built:** executable synthetic OAuth AS/MCP carrier + guarded zero-traffic deployment script.
- **Run:** `pytest 32/32 PASS`, staging run → `OPEN / AUTHORIZED_GCLOUD_RUNTIME_UNAVAILABLE`.
- **Observed:** no Google Cloud revision has been created by this session.
- **Proved:** isolated synthetic token lifecycle and staging policy under mocked Cloud Run responses.
- **OPEN:** GCP authenticated deployment authority; separate IAM/secret+image provenance; real external Google OIDC/CIMD; Cloud Run tagged HTTPS test.
