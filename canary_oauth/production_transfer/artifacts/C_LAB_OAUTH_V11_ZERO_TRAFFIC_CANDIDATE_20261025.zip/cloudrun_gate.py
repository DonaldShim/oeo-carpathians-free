"""Fail-closed staged Cloud Run zero-traffic guard.

Never deploy without explicitly requested --execute, existing restricted service account,
independent candidate image digest and a separate synthetic-only secret. No IAM writes,
no changes to science jobs or Cloud Run production traffic percentages.
"""
import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

PROJECT='project-4e9f56f4-a524-4759-91f'
REGION='europe-west1'
SERVICE='c-lab-gcp-control'
TAG='oauth-v11'
PREVIOUSLY_OBSERVED_MAIN='c-lab-gcp-control-custody-v1-prod-20261020'

def traffic_distribution(service):
    rows=service.get('status',{}).get('traffic',[])
    positive={}
    for t in rows:
        if int(t.get('percent') or 0)>0:
            rev=t.get('revisionName')
            positive[rev]=positive.get(rev,0)+int(t['percent'])
    return positive

def service_identity(service):
    return (service.get('spec',{}).get('template',{}).get('spec',{})
            .get('serviceAccountName'))

def gcloud_json(args):
    run=subprocess.run(['gcloud',*args],text=True,capture_output=True,check=True,timeout=40)
    return json.loads(run.stdout)

def verify_initial(service):
    if service.get('metadata',{}).get('name')!=SERVICE:
        raise ValueError('SERVICE_ID_MISMATCH')
    d=traffic_distribution(service)
    if any(r.get('tag')==TAG for r in service.get('status',{}).get('traffic',[])):
        raise ValueError('CANDIDATE_TAG_ALREADY_IN_USE')
    if len(d)!=1 or list(d.values())!=[100]:
        raise ValueError('NON_SINGLE_PROD_TRAFFIC_DISTRIBUTION')
    return d

def stage(args):
    if not shutil.which('gcloud'):
        return {'status':'OPEN','blocker':'AUTHORIZED_GCLOUD_RUNTIME_UNAVAILABLE','deployed':False}
    try:
        before=gcloud_json(['run','services','describe',SERVICE,'--project',PROJECT,
                            '--region',REGION,'--format=json'])
        baseline=verify_initial(before)
        prod_sa=service_identity(before)
        if not prod_sa or args.candidate_service_account==prod_sa:
            return {'status':'OPEN','blocker':'INDEPENDENT_TEST_SERVICE_ACCOUNT_REQUIRED','deployed':False}
        if not re.fullmatch(r'[a-z0-9-]+@[a-z0-9.-]+\.iam\.gserviceaccount\.com',args.candidate_service_account or ''):
            return {'status':'OPEN','blocker':'INVALID_TEST_SERVICE_ACCOUNT','deployed':False}
        if not re.fullmatch(r'europe-west1-docker\.pkg\.dev/project-4e9f56f4-a524-4759-91f/[a-z0-9_-]+/[a-z0-9_-]+@sha256:[0-9a-f]{64}',args.candidate_image or ''):
            return {'status':'OPEN','blocker':'CANDIDATE_IMAGE_DIGEST_REQUIRED','deployed':False}
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{3,110}:[1-9][0-9]*',args.test_secret_ref or ''):
            return {'status':'OPEN','blocker':'INDEPENDENT_TEST_SECRET_REQUIRED','deployed':False}
        if not args.execute:
            return {'status':'AFFIRMED_PREFLIGHT','deployed':False,'baseline_traffic':baseline,
                    'prod_revision_untouched':True,'candidate_service_account_distinct':True,
                    'candidate_image_pinned':True,'test_secret_configured':True,
                    'next':'Pass --execute only after owner approves independent service identity and image digest'}
        if not args.acknowledge_tagged_url:
            return {'status':'OPEN','blocker':'TAGGED_REVISION_REACHABILITY_ACK_REQUIRED','deployed':False}
        candidate_issuer='https://oauth-v11---c-lab-gcp-control-w7neqnzura-ew.a.run.app'
        argv=['run','deploy',SERVICE,'--project',PROJECT,'--region',REGION,
              '--image',args.candidate_image,'--no-traffic','--tag',TAG,
              '--service-account',args.candidate_service_account,
              '--min-instances','0','--max-instances','1',
              '--clear-cloudsql-instances','--clear-vpc-connector',
              '--clear-volumes','--clear-volume-mounts',
              '--set-env-vars',('C_LAB_V11_SYNTHETIC_ONLY=1,C_LAB_V11_ISSUER='+candidate_issuer+
                                ',C_LAB_V11_ACCESS_TTL=90'),
              '--set-secrets','C_LAB_V11_OPERATOR_KEY='+args.test_secret_ref,
              '--quiet']
        # No IAM updates. Production 100% remains pinned via --no-traffic.
        subprocess.run(['gcloud',*argv],check=True,capture_output=True,text=True,timeout=240)
        after=gcloud_json(['run','services','describe',SERVICE,'--project',PROJECT,
                           '--region',REGION,'--format=json'])
        current=traffic_distribution(after)
        if current != baseline:
            return {'status':'REJECTED','deployed':True,'critical':'PRODUCTION_TRAFFIC_CHANGED',
                    'before':baseline,'after':current,'requires_rollback':True}
        tagged=[r for r in after.get('status',{}).get('traffic',[]) if r.get('tag')==TAG]
        if len(tagged)!=1 or int(tagged[0].get('percent') or 0)!=0:
            return {'status':'REJECTED','deployed':True,'critical':'TAG_TRAFFIC_INVARIANT_FAILED',
                    'before':baseline,'after':current,'requires_rollback':True}
        revision=tagged[0].get('revisionName')
        details=gcloud_json(['run','revisions','describe',revision,'--project',PROJECT,
                             '--region',REGION,'--format=json'])
        revspec=details.get('spec',{})
        rev_sa=revspec.get('serviceAccountName')
        rev_image=(revspec.get('containers') or [{}])[0].get('image')
        has_inherited_volumes=bool(revspec.get('volumes'))
        env_names=[x.get('name') for x in (revspec.get('containers') or [{}])[0].get('env',[])]
        expected_names={'C_LAB_V11_SYNTHETIC_ONLY','C_LAB_V11_ISSUER',
                        'C_LAB_V11_ACCESS_TTL','C_LAB_V11_OPERATOR_KEY'}
        if (rev_sa!=args.candidate_service_account or rev_image!=args.candidate_image
            or has_inherited_volumes or set(env_names)!=expected_names):
            return {'status':'REJECTED','deployed':True,
                    'critical':'CANDIDATE_IMAGE_IDENTITY_ENV_INVARIANT_FAILED',
                    'production_percent_unchanged':True,'requires_rollback':True}
        return {'status':'AFFIRMED_ZERO_TRAFFIC_REVISION','deployed':True,
                'production_percent_unchanged':True,'production_revision':list(baseline),
                'tagged_revision':tagged[0].get('revisionName'),
                'tagged_url':tagged[0].get('url'),
                'no_scientific_jobs_created_by_script':True,'google_login_tested':False,
                'native_chatgpt_refresh_tested':False}
    except subprocess.CalledProcessError:
        return {'status':'OPEN','blocker':'GOOGLE_CLOUD_COMMAND_REJECTED','deployed':'UNKNOWN_VERIFY_CLOUD_RUN'}
    except Exception as exc:
        return {'status':'OPEN','blocker':str(exc) if isinstance(exc,ValueError) else type(exc).__name__,
                'deployed':False}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--candidate-image',default='')
    p.add_argument('--candidate-service-account',default='')
    p.add_argument('--test-secret-ref',default='')
    p.add_argument('--execute',action='store_true')
    p.add_argument('--acknowledge-tagged-url',action='store_true')
    p.add_argument('--output',default='')
    a=p.parse_args();result=stage(a)
    result['checked_utc']=datetime.now(timezone.utc).isoformat()
    result['cloud_project']=PROJECT;result['cloud_region']=REGION;result['service']=SERVICE
    doc=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if a.output:Path(a.output).write_text(doc,encoding='utf-8')
    print(doc)
    if result['status'] not in ('AFFIRMED_ZERO_TRAFFIC_REVISION','AFFIRMED_PREFLIGHT'):sys.exit(2)

if __name__=='__main__':main()
