import importlib, json, os, secrets
import fastapi.testclient
import pytest

os.environ['C_LAB_V11_SYNTHETIC_ONLY']='1'
os.environ['C_LAB_V11_ISSUER']='https://oauth-v11.example.test'
os.environ['C_LAB_V11_OPERATOR_KEY']='X'*48
os.environ['C_LAB_V11_ACCESS_TTL']='3'
import app as module
from fastapi.testclient import TestClient
c=TestClient(module.app)


def params(verifier):
    return {'client_id':module.TEST_CLIENT,'resource':module.RESOURCE,
            'redirect_uri':'http://127.0.0.1:7878/callback',
            'code_challenge':module.pkce(verifier)}

def init():
    verifier=secrets.token_urlsafe(48)
    r=c.post('/test/issue-code',json=params(verifier),headers={'X-Test-Operator':module.OPERATOR_KEY})
    assert r.status_code==200
    return r.json()['code'],verifier

def pair(code,verifier):
    return c.post('/token',data={'client_id':module.TEST_CLIENT,'resource':module.RESOURCE,
               'redirect_uri':'http://127.0.0.1:7878/callback',
               'grant_type':'authorization_code','code':code,'code_verifier':verifier})

def call(token=None):
    headers={'authorization':'Bearer '+token} if token else {}
    return c.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':3,'method':'tools/call',
            'params':{'name':'canary_control_health','arguments':{}}})


def test_01_health_never_science():
    x=c.get('/healthz').json(); assert x['ready'] and x['synthetic_only'] and not x['production_access'] and not x['science_access']

def test_02_resource_isolated_audience():
    x=c.get('/.well-known/oauth-protected-resource').json();assert x['resource']==module.RESOURCE and x['authorization_servers']==[module.ISSUER]

def test_03_discovery_refresh_capability():
    x=c.get('/.well-known/oauth-authorization-server').json();assert 'refresh_token' in x['grant_types_supported'] and x['issuer']==module.ISSUER

def test_04_no_fake_google_login():
    assert c.get('/authorize').status_code==503

def test_05_unauthenticated_tool_denied():
    assert call().json()['result']['isError'] and 'mcp/www_authenticate' in call().json()['result']['_meta']

def test_06_no_science_tool():
    assert [x['name'] for x in c.post('/mcp',json={'jsonrpc':'2.0','id':1,'method':'tools/list'}).json()['result']['tools']]==['canary_control_health']

def test_07_operator_key_required():
    assert c.post('/test/issue-code',json=params(secrets.token_urlsafe(48))).status_code==403

def test_08_wrong_resource_denied():
    p=params(secrets.token_urlsafe(48));p['resource']='https://c-lab-gcp-control-w7neqnzura-ew.a.run.app/mcp'
    assert c.post('/test/issue-code',json=p,headers={'X-Test-Operator':module.OPERATOR_KEY}).status_code==400

def test_09_auth_pkce_success():
    code,verifier=init();x=pair(code,verifier);assert x.status_code==200 and x.json()['refresh_token']

def test_10_wrong_verifier_denied():
    code,verifier=init();assert pair(code,secrets.token_urlsafe(48)).status_code==400

def test_11_code_replay_denied():
    code,verifier=init(); assert pair(code,verifier).status_code==200 and pair(code,verifier).status_code==400

def test_12_access_protected_read():
    code,verifier=init();x=pair(code,verifier).json();res=call(x['access_token']).json()['result'];assert not res['isError'] and json.loads(res['content'][0]['text'])['production_access'] is False

def test_13_refresh_rotation():
    code,verifier=init();old=pair(code,verifier).json();x=c.post('/token',data={'client_id':module.TEST_CLIENT,'resource':module.RESOURCE,'grant_type':'refresh_token','refresh_token':old['refresh_token']});assert x.status_code==200 and x.json()['refresh_token']!=old['refresh_token']

def test_14_replay_old_refresh_denied():
    code,verifier=init();old=pair(code,verifier).json();body={'client_id':module.TEST_CLIENT,'resource':module.RESOURCE,'grant_type':'refresh_token','refresh_token':old['refresh_token']};assert c.post('/token',data=body).status_code==200 and c.post('/token',data=body).status_code==400

def test_15_post_expiry_refresh_read(monkeypatch):
    fake=[1792945000];monkeypatch.setattr(module,'now',lambda:fake[0]);code,verifier=init();old=pair(code,verifier).json();fake[0]+=4; assert call(old['access_token']).json()['result']['isError'];new=c.post('/token',data={'client_id':module.TEST_CLIENT,'resource':module.RESOURCE,'grant_type':'refresh_token','refresh_token':old['refresh_token']}).json();assert not call(new['access_token']).json()['result']['isError']

def test_16_bad_client_denied():
    code,verifier=init();r=c.post('/token',data={'client_id':'malicious','resource':module.RESOURCE,'redirect_uri':'http://127.0.0.1:7878/callback','grant_type':'authorization_code','code':code,'code_verifier':verifier});assert r.status_code==400

def test_17_duplicate_parameter_denied():
    x=c.post('/token',content=f'client_id={module.TEST_CLIENT}&client_id=dup&resource={module.RESOURCE}&grant_type=refresh_token',headers={'content-type':'application/x-www-form-urlencoded'});assert x.status_code==400

def test_18_secrets_not_in_tool_results():
    code,verifier=init();pairx=pair(code,verifier).json();r=call(pairx['access_token']).text;assert pairx['access_token'] not in r and pairx['refresh_token'] not in r

def test_19_no_cloud_run_science_paths():
    for path in ['/run-job','/submit','/get_managed_job_status','/v54','/google/callback']:
        assert c.post(path).status_code==404

def test_20_disabled_by_default(monkeypatch):
    monkeypatch.setattr(module,'ENABLED',False)
    assert c.get('/healthz').json()['ready'] is False
    assert c.post('/token',data={}).status_code==503
