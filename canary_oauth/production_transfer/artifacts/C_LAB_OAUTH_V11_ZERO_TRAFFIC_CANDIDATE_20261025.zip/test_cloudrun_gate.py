import argparse
from unittest.mock import patch
import cloudrun_gate as m

def fixture(sa='production@project-4e9f56f4-a524-4759-91f.iam.gserviceaccount.com', traffic=None):
    return {'metadata':{'name':'c-lab-gcp-control'},
      'spec':{'template':{'spec':{'serviceAccountName':sa}}},
      'status':{'traffic':traffic or [
        {'revisionName':'c-lab-gcp-control-custody-v1-prod-20261020','percent':100},
        {'revisionName':'c-lab-gcp-control-00070-pir','percent':0,'tag':'research-v2-candidate'}]}}

def args(**kwargs):
    a=dict(candidate_image='europe-west1-docker.pkg.dev/project-4e9f56f4-a524-4759-91f/isolated/test@sha256:'+'a'*64,
           candidate_service_account='test-only@project-4e9f56f4-a524-4759-91f.iam.gserviceaccount.com',
           test_secret_ref='test_oauth_fixture:1',execute=False,acknowledge_tagged_url=False)
    a.update(kwargs);return argparse.Namespace(**a)

def test_21_distribution():
    assert m.verify_initial(fixture())=={'c-lab-gcp-control-custody-v1-prod-20261020':100}

def test_22_reject_mixed_traffic():
    try:m.verify_initial(fixture(traffic=[{'revisionName':'one','percent':95},{'revisionName':'two','percent':5}]))
    except ValueError:pass
    else:assert False

def test_23_no_gcloud_no_deploy():
    with patch.object(m.shutil,'which',return_value=None):
        assert m.stage(args())['blocker']=='AUTHORIZED_GCLOUD_RUNTIME_UNAVAILABLE'

def test_24_existing_identity_rejected():
    with patch.object(m.shutil,'which',return_value='gcloud'), patch.object(m,'gcloud_json',return_value=fixture()):
        assert m.stage(args(candidate_service_account=m.service_identity(fixture())))['blocker']=='INDEPENDENT_TEST_SERVICE_ACCOUNT_REQUIRED'

def test_25_mutable_image_rejected():
    with patch.object(m.shutil,'which',return_value='gcloud'), patch.object(m,'gcloud_json',return_value=fixture()):
        assert m.stage(args(candidate_image='europe-west1-docker.pkg.dev/image:latest'))['blocker']=='CANDIDATE_IMAGE_DIGEST_REQUIRED'

def test_26_missing_secret_rejected():
    with patch.object(m.shutil,'which',return_value='gcloud'), patch.object(m,'gcloud_json',return_value=fixture()):
        assert m.stage(args(test_secret_ref=''))['blocker']=='INDEPENDENT_TEST_SECRET_REQUIRED'

def test_27_dry_run_does_not_deploy():
    with patch.object(m.shutil,'which',return_value='gcloud'), patch.object(m,'gcloud_json',return_value=fixture()), patch.object(m.subprocess,'run') as run:
        assert m.stage(args())['status']=='AFFIRMED_PREFLIGHT' and not run.called

def test_28_execute_requires_tag_ack():
    with patch.object(m.shutil,'which',return_value='gcloud'), patch.object(m,'gcloud_json',return_value=fixture()), patch.object(m.subprocess,'run') as run:
        assert m.stage(args(execute=True))['blocker']=='TAGGED_REVISION_REACHABILITY_ACK_REQUIRED' and not run.called

def test_29_zero_traffic_revision_passes():
    after=fixture();after['status']['traffic'].append({'revisionName':'c-lab-gcp-control-oauth-v11','percent':0,'tag':'oauth-v11','url':'https://oauth-v11.example'})
    revision={'spec':{'serviceAccountName':args().candidate_service_account,
        'containers':[{'image':args().candidate_image,'env':[{'name':x} for x in ('C_LAB_V11_SYNTHETIC_ONLY','C_LAB_V11_ISSUER','C_LAB_V11_ACCESS_TTL','C_LAB_V11_OPERATOR_KEY')]}]}}
    with patch.object(m.shutil,'which',return_value='gcloud'), patch.object(m,'gcloud_json',side_effect=[fixture(),after,revision]),patch.object(m.subprocess,'run') as run:
        result=m.stage(args(execute=True,acknowledge_tagged_url=True)); assert result['status']=='AFFIRMED_ZERO_TRAFFIC_REVISION'
        cmd=run.call_args.args[0];assert '--no-traffic' in cmd and '--tag' in cmd and '--set-secrets' in cmd

def test_30_detect_any_main_traffic_loss():
    after=fixture(traffic=[{'revisionName':'c-lab-gcp-control-custody-v1-prod-20261020','percent':99},{'revisionName':'new','percent':1}]);after['status']['traffic'].append({'revisionName':'v11','tag':'oauth-v11','percent':0})
    with patch.object(m.shutil,'which',return_value='gcloud'), patch.object(m,'gcloud_json',side_effect=[fixture(),after]),patch.object(m.subprocess,'run'):
        result=m.stage(args(execute=True,acknowledge_tagged_url=True)); assert result['status']=='REJECTED' and result['critical']=='PRODUCTION_TRAFFIC_CHANGED'


def test_31_tag_collision_rejected():
    f=fixture();f['status']['traffic'].append({'revisionName':'old','percent':0,'tag':'oauth-v11'})
    try:m.verify_initial(f)
    except ValueError as e:assert str(e)=='CANDIDATE_TAG_ALREADY_IN_USE'
    else:assert False

def test_32_missing_tagged_revision_image_fail_closed():
    after=fixture();after['status']['traffic'].append({'revisionName':'v11','percent':0,'tag':'oauth-v11'})
    bad={'spec':{'serviceAccountName':args().candidate_service_account,
          'containers':[{'image':'gcr.io/other:latest','env':[]}]}}
    with patch.object(m.shutil,'which',return_value='gcloud'), patch.object(m,'gcloud_json',side_effect=[fixture(),after,bad]),patch.object(m.subprocess,'run'):
        result=m.stage(args(execute=True,acknowledge_tagged_url=True))
        assert result['status']=='REJECTED' and result['critical']=='CANDIDATE_IMAGE_IDENTITY_ENV_INVARIANT_FAILED'
