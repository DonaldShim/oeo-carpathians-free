"""Isolated synthetic OAuth resource/authorization prototype; NOT a production auth service.

No Cloud client, science tools, production storage, or Google credentials. Authentication
for test code issuance is ONLY via a local operator fixture, never a Google login.
The in-memory store is deliberately non-durable; it MUST NOT be promoted to live OAuth.
"""
from __future__ import annotations
import base64
import hashlib
import hmac
import os
import re
import secrets
import threading
import time
from urllib.parse import parse_qs
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response

app = FastAPI(title='C-Lab isolated OAuth V11', docs_url=None, redoc_url=None, openapi_url=None)
ISSUER = os.getenv('C_LAB_V11_ISSUER', 'https://oauth-v11.invalid').rstrip('/')
RESOURCE = ISSUER + '/mcp'
TEST_CLIENT = 'C_LAB_SYNTHETIC_V11'
ENABLED = os.getenv('C_LAB_V11_SYNTHETIC_ONLY') == '1'
OPERATOR_KEY = os.getenv('C_LAB_V11_OPERATOR_KEY', '')
TTL = int(os.getenv('C_LAB_V11_ACCESS_TTL', '90'))
lock = threading.RLock()
codes, tokens, sessions, events = {}, {}, {}, []


def now():
    return int(time.time())


def digest(token):
    return hashlib.sha256(token.encode()).hexdigest()


def deny(status, reason):
    return JSONResponse({'error': reason}, status_code=status,
                        headers={'Cache-Control':'no-store'})


def protected():
    return ENABLED and ISSUER.startswith('https://') and len(OPERATOR_KEY) >= 43 and 2 <= TTL <= 600


def pkce(verifier):
    return base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')


def mint(session_id):
    at = secrets.token_urlsafe(48)
    rt = secrets.token_urlsafe(48)
    tokens[digest(at)] = {'kind':'access','session':session_id,'expires':now()+TTL,'used':False}
    tokens[digest(rt)] = {'kind':'refresh','session':session_id,'expires':now()+3600,'used':False}
    events.append({'kind':'access_issued','session_id':session_id,'epoch':now()})
    return {'access_token':at,'refresh_token':rt,'expires_in':TTL,'token_type':'Bearer',
            'scope':'c_lab_canary.read offline_access'}


@app.get('/healthz')
def health():
    return {'component':'isolated-oauth-v11', 'ready':protected(),
            'synthetic_only':True,'production_access':False,'science_access':False,
            'state_durable':False}


@app.get('/.well-known/oauth-protected-resource')
@app.get('/.well-known/oauth-protected-resource/mcp')
def protected_metadata():
    if not protected(): return deny(503,'not_configured')
    return {'resource':RESOURCE,'authorization_servers':[ISSUER],
            'scopes_supported':['c_lab_canary.read','offline_access']}


@app.get('/.well-known/oauth-authorization-server')
def auth_metadata():
    if not protected(): return deny(503,'not_configured')
    return {'issuer':ISSUER,'authorization_endpoint':ISSUER+'/authorize',
            'token_endpoint':ISSUER+'/token','response_types_supported':['code'],
            'grant_types_supported':['authorization_code','refresh_token'],
            'code_challenge_methods_supported':['S256'],
            'token_endpoint_auth_methods_supported':['none'],
            'authorization_response_iss_parameter_supported':True,
            'scopes_supported':['c_lab_canary.read','offline_access']}


@app.get('/authorize')
def authorize():
    # No fake login in the public tagged revision; a real upstream IdP is mandatory.
    return deny(503,'real_identity_provider_not_configured')


@app.post('/test/issue-code')
async def test_code(request:Request):
    if not protected():return deny(503,'not_configured')
    if not hmac.compare_digest(request.headers.get('X-Test-Operator',''), OPERATOR_KEY):
        return deny(403,'operator_proof_required')
    data=await request.json()
    if not isinstance(data,dict) or data.get('client_id')!=TEST_CLIENT or data.get('resource')!=RESOURCE:
        return deny(400,'client_or_resource_mismatch')
    challenge=data.get('code_challenge','')
    redirect=data.get('redirect_uri','')
    if not re.fullmatch('[A-Za-z0-9_-]{43}',challenge) or redirect!='http://127.0.0.1:7878/callback':
        return deny(400,'invalid_pkce_or_redirect')
    code=secrets.token_urlsafe(48)
    with lock:
        codes[digest(code)]={'challenge':challenge,'redirect':redirect,'expires':now()+60,'used':False}
    return {'code':code,'iss':ISSUER}


@app.post('/token')
async def token(request:Request):
    if not protected():return deny(503,'not_configured')
    if request.headers.get('content-type','').split(';')[0]!='application/x-www-form-urlencoded':
        return deny(415,'invalid_content_type')
    data=await request.body()
    if len(data)>8192:return deny(413,'request_too_large')
    try:
        parsed=parse_qs(data.decode('utf-8'),strict_parsing=True)
    except (ValueError,UnicodeError):return deny(400,'invalid_request')
    if any(len(v)!=1 for v in parsed.values()):return deny(400,'duplicate_parameter')
    d={k:v[0] for k,v in parsed.items()}
    if d.get('client_id')!=TEST_CLIENT or d.get('resource')!=RESOURCE:
        return deny(400,'invalid_client_or_resource')
    if request.headers.get('authorization') or any(k in d for k in ('client_secret','client_assertion')):
        return deny(400,'unexpected_client_secret')
    kind=d.get('grant_type')
    if kind=='authorization_code':
        verifier=d.get('code_verifier','')
        if not re.fullmatch('[A-Za-z0-9._~-]{43,128}',verifier):return deny(400,'invalid_verifier')
        with lock:
            row=codes.get(digest(d.get('code','')))
            if not row or row['used'] or row['expires']<=now() or row['redirect']!=d.get('redirect_uri') or not hmac.compare_digest(row['challenge'],pkce(verifier)):
                return deny(400,'invalid_grant')
            row['used']=True
            family=secrets.token_hex(16)
            sessions[family]={'scope':'c_lab_canary.read offline_access','revoked':False}
            out=mint(family)
        return JSONResponse(out,headers={'Cache-Control':'no-store'})
    if kind=='refresh_token':
        with lock:
            row=tokens.get(digest(d.get('refresh_token','')))
            if not row or row['kind']!='refresh' or row['used'] or row['expires']<=now():
                return deny(400,'invalid_grant')
            if sessions[row['session']]['revoked']:return deny(400,'invalid_grant')
            row['used']=True
            events.append({'kind':'refresh_grant_received','session_id':row['session'],'epoch':now()})
            out=mint(row['session'])
            events.append({'kind':'refresh_success','session_id':row['session'],'epoch':now()})
        return JSONResponse(out,headers={'Cache-Control':'no-store'})
    return deny(400,'unsupported_grant_type')


@app.post('/mcp')
async def mcp(request:Request):
    if not protected():return deny(503,'not_configured')
    try:d=await request.json()
    except Exception:return deny(400,'invalid_json')
    if not isinstance(d,dict) or d.get('jsonrpc')!='2.0':return deny(400,'invalid_jsonrpc')
    method=d.get('method')
    if method=='initialize':
        return {'jsonrpc':'2.0','id':d.get('id'),'result':{'protocolVersion':'2025-03-26',
            'capabilities':{'tools':{}},'serverInfo':{'name':'OAuth V11 synthetic','version':'0.1'}}}
    if method=='tools/list':
        return {'jsonrpc':'2.0','id':d.get('id'),'result':{'tools':[{
            'name':'canary_control_health','inputSchema':{'type':'object','properties':{},'additionalProperties':False},
            'securitySchemes':[{'type':'oauth2','scopes':['c_lab_canary.read']}],
            'annotations':{'readOnlyHint':True,'destructiveHint':False}}]}}
    if method!='tools/call' or d.get('params',{}).get('name')!='canary_control_health':
        return {'jsonrpc':'2.0','id':d.get('id'),'error':{'code':-32601,'message':'Not found'}}
    bearer=request.headers.get('authorization','')
    with lock:
        access=tokens.get(digest(bearer[7:])) if bearer.startswith('Bearer ') else None
        if access and access['kind']=='access' and access['expires']>now() and not sessions[access['session']]['revoked']:
            events.append({'kind':'access_validated','session_id':access['session'],'epoch':now()})
            result={'component':'OAuth V11 synthetic','ok':True,'science_access':False,
                    'production_access':False,'session_id':access['session']}
            return {'jsonrpc':'2.0','id':d.get('id'),'result':{'isError':False,
                   'content':[{'type':'text','text':__import__('json').dumps(result)}]}}
    challenge='Bearer resource_metadata="'+ISSUER+'/.well-known/oauth-protected-resource/mcp"'
    return {'jsonrpc':'2.0','id':d.get('id'),'result':{'isError':True,
            '_meta':{'mcp/www_authenticate':[challenge]},
            'content':[{'type':'text','text':'Authentication required'}]}}
